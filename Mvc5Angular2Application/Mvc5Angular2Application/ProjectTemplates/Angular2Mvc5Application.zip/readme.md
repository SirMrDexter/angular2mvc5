﻿Sample Angular 2 RC1 and Mvc 5 application.

 

A simple application showing how to configure a mvc5 project to support angular2 RC1 (with typescript).




Installation Issues :




Required Visual Studio 2015 Update 2


 

Synchronize Node.JS Install Version with Visual Studio 2015

 

Correct this issue




Note : Using typings -v 0.8 : npm i typings@0.8

 

If using npm behind a proxy rename file "_typingsrc" to ".typingsrc" and configure it.

 

If package restoration problems occur, restore packages manually with the " npm i" command and check logs.

