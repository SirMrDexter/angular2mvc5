/// <reference path="browser/ambient/bootstrap/index.d.ts" />
/// <reference path="browser/ambient/core-js/index.d.ts" />
/// <reference path="browser/ambient/jquery/index.d.ts" />
