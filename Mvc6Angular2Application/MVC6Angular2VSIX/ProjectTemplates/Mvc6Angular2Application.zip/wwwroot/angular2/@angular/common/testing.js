"use strict";
var mock_location_strategy_1 = require('./testing/mock_location_strategy');
exports.MockLocationStrategy = mock_location_strategy_1.MockLocationStrategy;
var location_mock_1 = require('./testing/location_mock');
exports.SpyLocation = location_mock_1.SpyLocation;
//# sourceMappingURL=testing.js.map