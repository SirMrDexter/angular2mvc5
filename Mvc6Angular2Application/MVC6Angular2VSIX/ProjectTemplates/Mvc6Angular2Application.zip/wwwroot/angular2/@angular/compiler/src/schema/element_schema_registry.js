"use strict";
var ElementSchemaRegistry = (function () {
    function ElementSchemaRegistry() {
    }
    return ElementSchemaRegistry;
}());
exports.ElementSchemaRegistry = ElementSchemaRegistry;
//# sourceMappingURL=element_schema_registry.js.map