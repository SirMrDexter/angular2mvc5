"use strict";
var CompileBinding = (function () {
    function CompileBinding(node, sourceAst) {
        this.node = node;
        this.sourceAst = sourceAst;
    }
    return CompileBinding;
}());
exports.CompileBinding = CompileBinding;
//# sourceMappingURL=compile_binding.js.map