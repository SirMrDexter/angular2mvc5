"use strict";
var ChangeDetectorRef = (function () {
    function ChangeDetectorRef() {
    }
    return ChangeDetectorRef;
}());
exports.ChangeDetectorRef = ChangeDetectorRef;
//# sourceMappingURL=change_detector_ref.js.map