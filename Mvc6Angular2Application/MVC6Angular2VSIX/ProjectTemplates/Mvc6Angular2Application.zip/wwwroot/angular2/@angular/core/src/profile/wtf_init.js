"use strict";
/**
* This is here because DART requires it. It is noop in JS.
*/
function wtfInit() { }
exports.wtfInit = wtfInit;
//# sourceMappingURL=wtf_init.js.map