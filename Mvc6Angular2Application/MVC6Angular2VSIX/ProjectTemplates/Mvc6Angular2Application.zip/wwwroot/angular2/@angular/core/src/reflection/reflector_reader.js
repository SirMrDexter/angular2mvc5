"use strict";
/**
* Provides read-only access to reflection data about symbols. Used internally by Angular
* to power dependency injection and compilation.
*/
var ReflectorReader = (function () {
    function ReflectorReader() {
    }
    return ReflectorReader;
}());
exports.ReflectorReader = ReflectorReader;
//# sourceMappingURL=reflector_reader.js.map