"use strict";
// Public API for render
var api_1 = require('./render/api');
exports.RootRenderer = api_1.RootRenderer;
exports.Renderer = api_1.Renderer;
exports.RenderComponentType = api_1.RenderComponentType;
//# sourceMappingURL=render.js.map