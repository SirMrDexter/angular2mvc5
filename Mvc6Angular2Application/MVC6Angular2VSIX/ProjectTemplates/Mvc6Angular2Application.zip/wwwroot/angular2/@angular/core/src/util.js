"use strict";
// Public API for util
var decorators_1 = require('./util/decorators');
exports.Class = decorators_1.Class;
//# sourceMappingURL=util.js.map