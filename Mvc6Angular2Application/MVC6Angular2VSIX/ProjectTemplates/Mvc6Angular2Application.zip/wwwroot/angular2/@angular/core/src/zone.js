"use strict";
// Public API for Zone
var ng_zone_1 = require('./zone/ng_zone');
exports.NgZone = ng_zone_1.NgZone;
exports.NgZoneError = ng_zone_1.NgZoneError;
//# sourceMappingURL=zone.js.map