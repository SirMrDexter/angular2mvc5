"use strict";
var core_1 = require('@angular/core');
exports.ReflectionCapabilities = core_1.__core_private__.ReflectionCapabilities;
//# sourceMappingURL=core_private.js.map