"use strict";
var platform_browser_1 = require('@angular/platform-browser');
function getDOM() { return platform_browser_1.__platform_browser_private__.getDOM(); }
exports.getDOM = getDOM;
;
//# sourceMappingURL=platform_browser_private.js.map