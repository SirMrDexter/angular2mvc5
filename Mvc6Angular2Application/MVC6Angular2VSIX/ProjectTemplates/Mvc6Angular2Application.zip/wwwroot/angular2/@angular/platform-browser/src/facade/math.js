"use strict";
var lang_1 = require('./lang');
exports.Math = lang_1.global.Math;
exports.NaN = typeof exports.NaN;
//# sourceMappingURL=math.js.map