"use strict";
var core_1 = require('@angular/core');
exports.makeDecorator = core_1.__core_private__.makeDecorator;
//# sourceMappingURL=core_private.js.map