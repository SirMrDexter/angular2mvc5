"use strict";
var lang_1 = require('../src/facade/lang');
// This is here only so that after TS transpilation the file is not empty.
// TODO(rado): find a better way to fix this, or remove if likely culprit
// https://github.com/systemjs/systemjs/issues/487 gets closed.
var __ignore_me = lang_1.global;
var __make_dart_analyzer_happy = null;
//# sourceMappingURL=interfaces.js.map