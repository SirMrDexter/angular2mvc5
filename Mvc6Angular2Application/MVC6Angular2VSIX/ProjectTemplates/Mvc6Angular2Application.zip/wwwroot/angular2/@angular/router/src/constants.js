"use strict";
/**
* Name of the default outlet outlet.
* @type {string}
*/
exports.DEFAULT_OUTLET_NAME = "__DEFAULT";
//# sourceMappingURL=constants.js.map