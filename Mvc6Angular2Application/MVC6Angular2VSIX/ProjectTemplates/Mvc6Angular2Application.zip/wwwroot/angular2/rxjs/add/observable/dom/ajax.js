"use strict";
var Observable_1 = require('../../../Observable');
var ajax_1 = require('../../../observable/dom/ajax');
Observable_1.Observable.ajax = ajax_1.ajax;
//# sourceMappingURL=ajax.js.map