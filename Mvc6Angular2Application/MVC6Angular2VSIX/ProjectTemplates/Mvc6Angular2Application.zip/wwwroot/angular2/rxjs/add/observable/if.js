"use strict";
var Observable_1 = require('../../Observable');
var if_1 = require('../../observable/if');
Observable_1.Observable.if = if_1._if;
//# sourceMappingURL=if.js.map