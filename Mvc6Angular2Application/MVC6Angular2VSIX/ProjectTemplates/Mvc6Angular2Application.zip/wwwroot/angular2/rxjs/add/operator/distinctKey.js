"use strict";
var Observable_1 = require('../../Observable');
var distinctKey_1 = require('../../operator/distinctKey');
Observable_1.Observable.prototype.distinctKey = distinctKey_1.distinctKey;
//# sourceMappingURL=distinctKey.js.map