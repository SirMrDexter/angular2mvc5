"use strict";
var Observable_1 = require('../../Observable');
var distinctUntilKeyChanged_1 = require('../../operator/distinctUntilKeyChanged');
Observable_1.Observable.prototype.distinctUntilKeyChanged = distinctUntilKeyChanged_1.distinctUntilKeyChanged;
//# sourceMappingURL=distinctUntilKeyChanged.js.map